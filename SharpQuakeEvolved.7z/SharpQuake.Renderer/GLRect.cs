﻿using System;

namespace SharpQuake.Renderer
{
    public struct glRect_t
    {
        public Byte l, t, w, h;
    }
}
