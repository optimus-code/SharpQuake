﻿namespace SharpQuake.Renderer.Textures
{
    public enum MTexTarget
    {
        TEXTURE0_SGIS = 0x835E,
        TEXTURE1_SGIS = 0x835F
    }
}
