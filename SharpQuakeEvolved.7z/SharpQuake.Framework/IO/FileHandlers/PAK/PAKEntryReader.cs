﻿/// <copyright>
///
/// SharpQuakeEvolved changes by optimus-code, 2019
/// 
/// Based on SharpQuake (Quake Rewritten in C# by Yury Kiselev, 2010.)
///
/// Copyright (C) 1996-1997 Id Software, Inc.
///
/// This program is free software; you can redistribute it and/or
/// modify it under the terms of the GNU General Public License
/// as published by the Free Software Foundation; either version 2
/// of the License, or (at your option) any later version.
///
/// This program is distributed in the hope that it will be useful,
/// but WITHOUT ANY WARRANTY; without even the implied warranty of
/// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
///
/// See the GNU General Public License for more details.
///
/// You should have received a copy of the GNU General Public License
/// along with this program; if not, write to the Free Software
/// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
/// </copyright>

using System;
using System.IO;
using System.IO.Compression;
using System.Linq;

namespace SharpQuake.Framework.IO.FileHandlers.PAK
{
    public class PAKEntryReader : IArchiveEntryReader, IDisposable
    {
        public String Path
        {
            get;
            private set;
        }

        public Stream Stream
        {
            get;
            private set;
        }

        public Int64 Length
        {
            get
            {
                return _entry?.filelen ?? 0;
            }
        }

        private readonly Pak _archive;
        private readonly MemoryPakFile _entry;

        public PAKEntryReader( Pak archive, String path )
        {
            Path = path;
            _archive = archive;
            _entry = _archive.files.FirstOrDefault( e => e.name == Path );

            var pakStream = ( FileStream ) _archive.stream.BaseStream;
            Stream = new FileStream( pakStream.Name, FileMode.Open, FileAccess.Read, FileShare.Read );
            Stream.Seek( _entry.filepos, SeekOrigin.Begin );
        }

        public void Dispose( )
        {
            Stream?.Dispose( );
        }
    }
}
