﻿namespace SharpQuake.Framework
{
    public enum SyncType
    {
        ST_SYNC = 0,
        ST_RAND
    } // synctype_t;
}
